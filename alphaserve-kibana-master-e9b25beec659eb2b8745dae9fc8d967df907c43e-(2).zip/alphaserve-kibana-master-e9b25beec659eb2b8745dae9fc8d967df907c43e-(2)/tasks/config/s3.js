module.exports = function () {
  return {
    release: {
      bucket: 'download.elasticsearch.org',
      access: 'private',
      debug: false
    }
  };
};
