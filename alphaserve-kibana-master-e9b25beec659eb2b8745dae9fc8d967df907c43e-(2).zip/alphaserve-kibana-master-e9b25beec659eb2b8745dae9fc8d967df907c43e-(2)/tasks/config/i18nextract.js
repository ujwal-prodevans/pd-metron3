export default function () {
  return {
    default_options: {
      src: ['src/**/*.js', 'src/**/*.html'],
      lang: ['en'],
      dest: 'build/i18n_extract'
    }
  };
}
