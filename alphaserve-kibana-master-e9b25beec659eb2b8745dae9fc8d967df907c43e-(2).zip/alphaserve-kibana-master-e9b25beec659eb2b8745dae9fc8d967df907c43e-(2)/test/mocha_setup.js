require('../src/optimize/babel/register');
