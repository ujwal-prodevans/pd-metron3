import React from 'react';

import {
  KuiInfoButton,
} from '../../../../components';

export default () => (
  <div>
    <KuiInfoButton></KuiInfoButton>
  </div>
);

