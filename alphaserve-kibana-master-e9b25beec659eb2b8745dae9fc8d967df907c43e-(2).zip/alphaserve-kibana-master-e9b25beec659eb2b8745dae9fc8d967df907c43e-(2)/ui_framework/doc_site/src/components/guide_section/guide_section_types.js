export const GuideSectionTypes = {
  JS: 'JavaScript',
  HTML: 'HTML',
};
