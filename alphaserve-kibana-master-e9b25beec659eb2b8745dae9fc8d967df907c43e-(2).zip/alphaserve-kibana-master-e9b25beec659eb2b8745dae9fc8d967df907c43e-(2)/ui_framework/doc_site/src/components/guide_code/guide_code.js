import React from 'react';

export const GuideCode = props => (
  <code className="guideCode">{props.children}</code>
);
