import React from 'react';

export const GuideSandbox = props => (
  <div className="guideSandbox">
    {props.children}
  </div>
);
