import React from 'react';

export const GuideText = props => (
  <div className="guideText">{props.children}</div>
);
